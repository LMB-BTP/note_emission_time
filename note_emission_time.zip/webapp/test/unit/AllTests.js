sap.ui.define([
	"LMBR_CUSTOMER_APP/note_emission_time/test/unit/controller/V0.controller"
], function () {
	"use strict";
});